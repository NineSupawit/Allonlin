const Ndata = [
]

export default Ndata
