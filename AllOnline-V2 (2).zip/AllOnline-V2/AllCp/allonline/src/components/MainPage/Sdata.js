const Sdata = [
  {
    id: 1,
    // title: "",
    // desc: "",
    cover: "./images/SlideCard/slide-1.png",
  },
  {
    id: 2,
    // title: "",
    // desc: "",
    cover: "./images/SlideCard/slide-2.png",
  },
  {
    id: 3,
    // title: "",
    // desc: "",
    cover: "./images/SlideCard/slide-3.png",
  },
  {
    id: 4,
    // title: "",
    // desc: "",
    cover: "./images/SlideCard/slide-4.png",
  },
  {
    id: 5,
    // title: "",
    // desc: "",
    cover: "./images/SlideCard/slide-5.png",
  },
]
export default Sdata
