import React from "react"

const Categories = () => {
  const data = [
    {
      cateImg: "./images/category/cat1.png",
      cateName: "เครื่องดื่มเเละผงชงดื่ม",
    },
    {
      cateImg: "./images/category/cat2.png",
      cateName: "เครื่องปรุงรสเเละของเเห้ง",
    },
    {
      cateImg: "./images/category/cat3.png",
      cateName: "ขนมขบเคี้ยวเเละช๊อกโกเเลต",
    },
    {
      cateImg: "./images/category/cat4.png",
      cateName: "อาหารสด ผักผลไม้เเละเบเกอรี่",
    },
    {
      cateImg: "./images/category/cat5.png",
      cateName: "สุขภาพ",
    },
    {
      cateImg: "./images/category/cat6.png",
      cateName: "ความงามเเละของใช้ส่วนตัว",
    },
    {
      cateImg: "./images/category/cat7.png",
      cateName: "ของใช้ในบ้าน",
    },
    {
      cateImg: "./images/category/cat8.png",
      cateName: "เเม่เเละเด็ก ผู้สูงอายุ",
    },
  ]

  const handleBoxClick = (cateName) => {
    const searchUrl = `https://www.allonline.7eleven.co.th/supermarket/beverages-and-powder-tonics/${cateName}`
    window.open(searchUrl, '_blank')
  }
  return (
    <>
      <div className='category'>
        {data.map((value, index) => {
          return (
            <div className='box f_flex' key={index} onClick={() => handleBoxClick(value.cateName)}>
              <img src={value.cateImg} alt='' />
              <span>{value.cateName}</span>
              
            </div>
          )
        })}
      </div>
    </>
  )
}

export default Categories

