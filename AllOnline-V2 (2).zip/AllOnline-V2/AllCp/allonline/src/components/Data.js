const Data = {
  productItems: [
    {
      id: 1,
      cover: "./images/flash/flash-6.png",
      name: "โฟร์โมสต์ นมUHT รสหวาน 225 มล. ยกลัง 36 กล่อง ",
      price: 365,
    },
    {
      id: 2,
      cover: "./images/flash/flash-2.png",
      name: "ดีมอลต์ นมUHT รสช็อกโกแลต 180 มล. (ยกลัง 48 กล่อง)",
      price: 502,
    },
    {
      id: 3,
      cover: "./images/flash/flash-3.png",
      name: "กูลิโกะโคลลอน รสช็อกโกแลต 46 กรัม (แพ็ก 10 ชิ้น)",
      price: 144,
    },
    {
      id: 4,
      cover: "./images/flash/flash-4.png",
      name: "คนอร์คัพโจ๊กรสกุ้ง-ปูอัดชนิดถ้วย 32 กรัม (แพ็ก 6 ถ้วย)",
      price: 90,
    },
    {
      id: 5,
      cover: "./images/flash/flash-1.png",
      name: "แอนมัม มาเทอร์น่า นมผงพร่องมันเนย 600 กรัม",
      price: 370 ,
    },
  ],
}
export default Data
