import { Link } from "react-router-dom"
const Sdata = {
  shopItems: [
  
    {
      id: 7,
      cover: "./images/shops/shops-1.png",
      name: "เป๊ปซี่ 1.5 ลิตร (แพ็ก 12 ขวด)",
      price: "388",
      discount: "25",
    },
    {
      id: 8,
      cover: "./images/shops/shops-2.png",
      name: "สิงห์ เลมอนโซดา (แพ็ก 6 กระป๋อง)",
      price: "160",
      discount: "10",
    },
    {
      id: 9,
      cover: "./images/shops/shops-3.png",
      name: "น้ำดื่มสิงห์ 600 มล. (แพ็ก 12 ขวด)",
      price: "130",
      discount: "50 ",
    },
    {
      id: 10,
      cover: "./images/shops/shops-4.png",
      name: "ปาร์ตี้ รสครองแครง 53 กรัม",
      price: "120",
      discount: "10 ",
    },
    {
      id: 11,
      cover: "./images/shops/shops-5.png",
      name: "กูลิโกะป๊อกกี้ บิสกิตรสช็อกโกแลต",
      price: "200",
      discount: "20 ",
    },
    {
      id: 12,
      cover: "./images/shops/shops-7.png",
      name: "แคลชีส เวเฟอร์สอดไส้ครีมรสชีส",
      price: "72",
      discount: "20 ",
    },
    {
      id: 13,
      cover: "./images/shops/shops-8.png",
      name: "นูเทลล่า เฮเซลนัทบดผสมโกโก้",
      price: "121",
      discount: "5 ",
    },
    {
      id: 14,
      cover: "./images/shops/shops-9.png",
      name: "วีฟู้ดส์ ขนมปังกรอบกะทิไส้สับปะรด",
      price: "69",
      discount: "10",
    },
    {
      id: 15,
      cover: "./images/shops/shops-10.png",
      name: "ฉัตรส้ม ข้าวหอมผสม 5 กิโลกรัม",
      price: "150",
      discount: "2",
    },
  ],

}
export default Sdata