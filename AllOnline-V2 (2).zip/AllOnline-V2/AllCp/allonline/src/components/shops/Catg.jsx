import React from "react"

const Catg = () => {
  const data = [
    {
      cateImg: "./images/category/cat-1.png",
      cateName: "",
    },
    {
      cateImg: "./images/category/cat-2.png",
      cateName: "",
    },
    {
      cateImg: "./images/category/cat-1.png",
      cateName: "",
    },
    {
      cateImg: "./images/category/cat-2.png",
      cateName: "",
    },
    {
      cateImg: "./images/category/cat-1.png",
      cateName: "",
    },
    {
      cateImg: "./images/category/cat-2.png",
      cateName: "",
    },
  ]
  return (
    <>
      {/* <div className='category'>
        <div className='chead d_flex'>
          <h1>สินค้า </h1>
          <h1>ร้านค้า </h1>
        </div>
        {data.map((value, index) => {
          return (
            <div className='box f_flex' key={index}>
              <span>{value.cateName}</span>
            </div>
          )
        })}
        <div className='box box2'>
        </div>
      </div> */}
    </>
  )
}

export default Catg
