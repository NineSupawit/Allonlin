import React from "react"
import "./style.css"
import TopCart from "./TopCart"

const Order = () => {
  return (
    <>
      <section className='Order background'>
        <div className='container'>
          <div className='heading d_flex'>
            <div className='heading-left row  f_flex'>
              <i className='fa-solid fa-border-all'></i>
              <h2>สินค้าขายดี</h2>
            </div>
            <div className='heading-right row '>
              <span>ดูทั้งหมด</span>
              <i className='fa-solid fa-caret-right'></i>
            </div>
          </div>
          <TopCart />
        </div>
      </section>
    </>
  )
}

export default Order
