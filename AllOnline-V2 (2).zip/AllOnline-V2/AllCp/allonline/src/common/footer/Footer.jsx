import React from "react"
import "./style.css"

const Footer = () => {
  return (
    <>
      <footer>
        <div className='container grid2'>
          <div className='box'>
            <h1>AllOnline</h1>
            <div className='icon d_flex'>
              <div className='img d_flex'>
                <i class='fa-brands fa-google-play'></i>
                <span>Google Play</span>
                <button></button>
                <link rel="stylesheet" href="https://play.google.com/store/apps/details?id=asuk.com.android.app&hl=th&gl=US&pli=1" />
              </div>

              <div className='img d_flex'>
                <i class='fa-brands fa-app-store-ios'></i>
                <span>App Store</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}

export default Footer
